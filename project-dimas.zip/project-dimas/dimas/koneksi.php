<?php

//konfigurasi database
$host       =   "localhost";
$user       =   "root";
$password   = "";
$database   =   "latihan_1";
// perintah php untuk akses ke database 
$koneksi = mysqli_connect($host, $user, $password, $database);
?>