<?php
include 'koneksi.php';
//menyimpan data kedalam variabel
$id_mahasiswa   = $_POST['id_mahasiswa'];
$nim            = $_POST['nim'];
$nama           = $_POST['nama'];
$jenis_kelamin  = $_POST['jenis_kelamin'];
$jurusan        = $_POST['jurusan'];
$alamat         = $_POST['alamat'];
// query SQL untuk insert data
$query="UPDATE mahasiswa SET nim='$nim',nama='$nama',jenis_kelamin='$jenis_kelamin',jurusan='$jurusan',alamat='$alamat' where id_mahasiswa='$id_mahasiswa'";
mysqli_query($koneksi,$query);
//mengalihkan kedalam index.php
header("location:index.php");
?>