<html>
    <head>
        <title>FORM INPUT DATA MAHASISWA</title>
</head>
<body>
    <form method="post" action="simpan.php">
    <table>
        <tr><td>NIM</td><td><input type="text" onkeyup="isi_otomatis()" name="nim"></td></tr>
        <tr><td>NAMA</td><td><input type="text" onkeyup="isi_otomatis()" name="nama"></td></tr>
        <tr><td>JENIS KELAMIN</td><td>
        <input type="radio" nam="jenis_kelamin" value="L">Laki Laki
        <input type="radio" nam="jenis_kelamin" value="P">Perempuan
</td></tr>
        <tr><td>JURUSAN</td><td>
            <select name="jurusan">
                <option value="TEKNIK INFORMATIKA">TEKNIK INFORMATIKA</option>
                <option value="PERTANIAN">PERTANIAN</option>
                <option value="PETERNAKAN">PETERNAKAN</option>
                <option value="HUBUNGAN INTERNATIONAL">HUBUNGAN INTERNASIONAL</option>
                <option value="HUKUM">HUKUM</option>
                <option value="DKV">DKV</option>
                <option value="HUKUM ISLAM">HUKUM ISLAM</option>
                <option value="BIOLOGI">BIOLOGI</option>
                <option value="PSIKOLOGI">PSIKOLOGI</option>
            </select>   
            <tr><td>ALAMAT</td><td><input type="text" name="alamat"></td></tr>
                <tr><td colspan="2"><button type="submit" value="simpan">SIMPAN</button></td></tr>
    </table>
    </form>
</body<